Downloaded from  https://packages.debian.org/unstable/all/hunspell-de-de/download

extract *.aff and *.dic files
from

C:\Users\User\Downloads\hunspell-de-de_20161207-16_all.deb\data.tar\.\usr\share\hunspell\

to

C:\Users\User\scoop\apps\msys2\current\clang64\share\hunspell

        **********************************************
                           igerman98
                       *****************
Ein deutsches Wörterbuch zur Rechtschreibkontrolle nach den neuen
 Rechtschreibregeln mit den Programmen Ispell, Myspell, Hunspell
        **********************************************